import { motion } from 'framer-motion';

interface ContentSectionProps {
  title: string;
  icon: string;
  children: React.ReactNode;
}

export default function ContentSection({ title, icon, children }: ContentSectionProps) {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="mb-12"
    >
      <h3 className="text-2xl font-bold text-gray-800 mb-4 flex items-center">
        <i className={`${icon} mr-2 text-emerald-500`}></i>
        {title}
      </h3>
      <div className="bg-white p-6 rounded-xl shadow-sm">
        {children}
      </div>
    </motion.section>
  );
}