import { useState } from 'react';
import { motion } from 'framer-motion';

interface ImageGalleryProps {
  images: string[];
  title: string;
}

export default function ImageGallery({ images, title }: ImageGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const openImageModal = (image: string) => {
    setSelectedImage(image);
    document.body.style.overflow = 'hidden';
  };
  
  const closeImageModal = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };
  
  return (
    <div className="mt-12">
      <h3 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
        <i className="fa-solid fa-camera mr-2 text-emerald-500"></i>
        {title}
      </h3>
      
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {images.map((image, index) => (
          <motion.div 
            key={index}
            whileHover={{ scale: 1.03 }}
            transition={{ duration: 0.3 }}
            className="cursor-pointer rounded-lg overflow-hidden shadow-md hover:shadow-lg"
          >
            <img 
              src={image} 
              alt={`${title} - 图片 ${index + 1}`}
              className="w-full h-40 object-cover"
              onClick={() => openImageModal(image)}
            />
          </motion.div>
        ))}
      </div>
      
      {selectedImage && (
        <div 
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={closeImageModal}
        >
          <button 
            className="absolute top-4 right-4 text-white text-2xl"
            onClick={closeImageModal}
          >
            <i className="fa-solid fa-times"></i>
          </button>
          
          <img 
            src={selectedImage} 
            alt="大图预览"
            className="max-h-[90vh] max-w-full object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}