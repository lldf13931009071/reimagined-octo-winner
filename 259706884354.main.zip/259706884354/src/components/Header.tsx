import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

export default function Header() {
  const location = useLocation();
  
  const navItems = [
    { label: '首页', path: '/' },
    { label: '景点介绍', path: '/' },
    { label: '关于我们', path: '/about' }
  ];
  
  return (
    <header className="bg-white shadow-md sticky top-0 z-50 transition-all duration-300">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold text-emerald-600 flex items-center">
            <i className="fa-solid fa-mountain mr-2"></i>
            <span>探索中国</span>
          </Link>
          
          <nav className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.path}
                className={cn(
                  "text-gray-700 hover:text-emerald-600 font-medium transition-colors",
                  location.pathname === item.path ? "text-emerald-600 border-b-2 border-emerald-500 pb-1" : ""
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          
          <button className="md:hidden text-gray-700 focus:outline-none">
            <i className="fa-solid fa-bars text-xl"></i>
          </button>
        </div>
      </div>
    </header>
  );
}