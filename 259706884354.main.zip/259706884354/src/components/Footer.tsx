import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-10 mt-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <i className="fa-solid fa-mountain mr-2"></i>
              探索中国
            </h3>
            <p className="text-gray-400">
              发现中国最美的风景，体验丰富的文化遗产，开启难忘的旅行之旅。
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">快速链接</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link to="/" className="hover:text-white transition-colors">首页</Link></li>
              <li><Link to="/about" className="hover:text-white transition-colors">关于我们</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">联系我们</h4>
            <p className="text-gray-400 flex items-center mb-2">
              <i className="fa-solid fa-envelope mr-2"></i> contact@travelchina.com
            </p>
            <p className="text-gray-400 flex items-center">
              <i className="fa-solid fa-phone mr-2"></i> +86 123 4567 8910
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-500">
          <p>&copy; {new Date().getFullYear()} 探索中国旅行网. 保留所有权利.</p>
        </div>
      </div>
    </footer>
  );
}