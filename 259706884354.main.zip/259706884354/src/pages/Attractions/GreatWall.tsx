import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ImageGallery from '@/components/ImageGallery';
import ContentSection from '@/components/ContentSection';
import { getAttractionById } from '@/data/attractions';

export default function GreatWall() {
  const attraction = getAttractionById('greatWall');
  
  if (!attraction) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">景点未找到</h1>
          <p className="text-gray-600 mb-8">抱歉，请求的景点不存在或已移除。</p>
          <Link to="/" className="inline-block bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300">
            返回首页
          </Link>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh] min-h-[400px]">
          <img 
            src={attraction.images[0]} 
            alt={attraction.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex items-end">
            <div className="container mx-auto px-4 pb-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{attraction.name}</h1>
                <div className="flex items-center text-gray-200">
                  <i className="fa-solid fa-map-marker-alt mr-2"></i>
                  <span>{attraction.location}</span>
                  <span className="mx-3">•</span>
                  <span>{attraction.level}</span>
                </div>
              </motion.div>
            </div>
          </div>
          
          <div className="absolute top-4 left-4">
            <Link to="/" className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300 backdrop-blur-sm">
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </div>
        </section>
        
        {/* Content Sections */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <ContentSection title="景点概述" icon="fa-solid fa-info-circle">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">地理位置</h4>
                    <p className="font-medium text-gray-800">{attraction.location}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">景区等级</h4>
                    <p className="font-medium text-gray-800">{attraction.level}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">建议游玩时间</h4>
                    <p className="font-medium text-gray-800">{attraction.suggestedTime}</p>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  长城是中国古代的军事防御工程，是世界文化遗产之一，也是世界七大奇迹之一。长城修筑的历史可上溯到西周时期，秦灭六国统一天下后，秦始皇连接和修缮战国长城，始有"万里长城"之称。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  长城不是一道单纯孤立的城墙，而是以城墙为主体，同大量的城、障、亭、标相结合的防御体系。长城资源主要分布在河北、北京、天津、山西、陕西、甘肃、内蒙古、黑龙江、吉林、辽宁、山东、河南、青海、宁夏、新疆等15个省区市。
                </p>
              </ContentSection>
              
              <ContentSection title="景点特色" icon="fa-solid fa-star">
                <p className="text-gray-700 leading-relaxed mb-4">
                  长城的防御工程体系包括城墙、敌楼、关城、墩堡、营城、卫所、镇城烽火台等多种防御工事，构成了一个完整的防御体系。长城的城墙平均高度为7.8米，有些地段高达14米。凡是山岗陡峭的地方构筑的比较低，平坦的地方构筑得比较高；紧要的地方比较高，一般的地方比较低。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  长城的城墙结构，在重要的关隘地方一般都以砖石砌筑，内填泥土石块；在一些非紧要的地方则采用夯土筑成。城墙顶部的外侧设有高约2米的垛口，内侧设有高约1米的女墙。垛口上部有瞭望口，下部有射洞，以便观察和射击。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  长城的关城是长城防御体系的核心，一般都建在地势险要的交通要道上。著名的关城有山海关、嘉峪关、居庸关、雁门关、娘子关等。这些关城不仅是军事防御的重要据点，也是古代中原地区与边疆地区经济文化交流的重要通道。
                </p>
              </ContentSection>
              
              <ContentSection title="历史背景" icon="fa-solid fa-history">
                <p className="text-gray-700 leading-relaxed mb-4">
                  长城始建于西周时期，著名的典故"烽火戏诸侯"就源于此。春秋战国时期列国争霸，互相防守，长城修筑进入第一个高潮，但此时修筑的长度都比较短。秦统一六国后，秦始皇派蒙恬北伐匈奴，并连接各国长城，始成万里长城。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  汉朝继续对长城进行修建，以抵御北方匈奴的侵袭。从汉文帝到汉宣帝，筑成了一条西起大宛贰师城、东至鸭绿江北岸、全长近一万公里的长城。汉长城是历史上最长的长城。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  明朝是最后一个大修长城的朝代，今天人们所看到的长城多是此时修筑。明朝修筑长城的目的主要是为了防御北方蒙古和女真等游牧民族的侵扰。明长城总长度为8851.8千米，是中国历史上修筑长城规模最大、质量最高的时期。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  1987年12月，长城被列入世界文化遗产。长城作为中华民族的象征，承载着中华民族的历史记忆和文化精神，是中华民族的骄傲。
                </p>
              </ContentSection>
              
              <ContentSection title="必游景点" icon="fa-solid fa-map-pin">
                <ul className="space-y-4">
                  {attraction.highlights.map((highlight, index) => (
                    <li key={index} className="flex">
                      <div className="flex-shrink-0 h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-xs font-medium text-emerald-600">{index + 1}</span>
                      </div>
                      <p className="text-gray-700">{highlight}</p>
                    </li>
                  ))}
                </ul>
              </ContentSection>
              
              <ImageGallery images={attraction.images} title="精美图片集" />
            </div>
            
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="bg-emerald-50 p-6 rounded-xl mb-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">旅行小贴士</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-clock text-emerald-600 mr-2"></i>
                        最佳旅游时间
                      </h4>
                      <p className="text-gray-600 text-sm">
                        春季（4-5月）和秋季（9-10月）是游览长城的最佳时节，气候宜人，景色优美。夏季气温较高，注意防晒；冬季寒冷，但游客较少，可欣赏雪景。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-shoe-prints text-emerald-600 mr-2"></i>
                        游览建议
                      </h4>
                      <p className="text-gray-600 text-sm">
                        北京周边有多个长城景区，各有特色：八达岭开发最完善，交通便利；慕田峪景色秀美，植被覆盖率高；司马台险峻壮观，保留原始风貌。可根据个人喜好选择。游览长城需要较多体力，建议穿着舒适的运动鞋，携带足够的饮用水。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-subway text-emerald-600 mr-2"></i>
                        交通指南
                      </h4>
                      <p className="text-gray-600 text-sm">
                        八达岭长城：地铁13号线到龙泽站，换乘877路公交车直达；或乘坐京张高铁至八达岭长城站。<br />
                        慕田峪长城：东直门乘坐916路公交车至怀柔北大街站，换乘H23/H24路公交车；或选择旅游专线巴士。<br />
                        也可选择包车或参加一日游团，方便快捷。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-ticket text-emerald-600 mr-2"></i>
                        门票信息
                      </h4>
                      <p className="text-gray-600 text-sm">
                        八达岭长城：旺季40元，淡季35元<br />
                        慕田峪长城：45元<br />
                        司马台长城：40元<br />
                        部分景区可选择缆车或滑车上下，需另付费用
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Great%20Wall%20sections%20map&sign=008632323f16c7445f2d883c381fad88" 
                    alt="长城各段位置图"
                    className="w-full h-auto"
                  />
                  <div className="p-4 bg-gray-50">
                    <h4 className="font-medium text-gray-800 mb-1">长城主要游览段分布</h4>
                    <p className="text-xs text-gray-500">点击查看大图</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}