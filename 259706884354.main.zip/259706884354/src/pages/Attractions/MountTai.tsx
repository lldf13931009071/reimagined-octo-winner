import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ImageGallery from '@/components/ImageGallery';
import ContentSection from '@/components/ContentSection';
import { getAttractionById } from '@/data/attractions';

export default function MountTai() {
  const attraction = getAttractionById('mountTai');
  
  if (!attraction) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">景点未找到</h1>
          <p className="text-gray-600 mb-8">抱歉，请求的景点不存在或已移除。</p>
          <Link to="/" className="inline-block bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300">
            返回首页
          </Link>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh] min-h-[400px]">
          <img 
            src={attraction.images[0]} 
            alt={attraction.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex items-end">
            <div className="container mx-auto px-4 pb-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{attraction.name}</h1>
                <div className="flex items-center text-gray-200">
                  <i className="fa-solid fa-map-marker-alt mr-2"></i>
                  <span>{attraction.location}</span>
                  <span className="mx-3">•</span>
                  <span>{attraction.level}</span>
                </div>
              </motion.div>
            </div>
          </div>
          
          <div className="absolute top-4 left-4">
            <Link to="/" className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300 backdrop-blur-sm">
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </div>
        </section>
        
        {/* Content Sections */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <ContentSection title="景点概述" icon="fa-solid fa-info-circle">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">地理位置</h4>
                    <p className="font-medium text-gray-800">{attraction.location}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">景区等级</h4>
                    <p className="font-medium text-gray-800">{attraction.level}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">建议游玩时间</h4>
                    <p className="font-medium text-gray-800">{attraction.suggestedTime}</p>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  泰山是中国五岳之首，有"天下第一山"之称，是中国传统文化中"天人合一"思想的寄托之地。泰山位于山东省中部，主峰玉皇顶海拔1545米，气势雄伟磅礴，有"五岳独尊"之美誉。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  泰山拥有丰富的自然景观和人文景观，是世界文化与自然双重遗产。泰山风景以壮丽著称，重叠的山势，厚重的形体，苍松巨石的烘托，云烟的变化，使它在雄浑中兼有明丽，静穆中透着神奇。
                </p>
              </ContentSection>
              
              <ContentSection title="景点特色" icon="fa-solid fa-star">
                <p className="text-gray-700 leading-relaxed mb-4">
                  泰山的自然景观雄伟壮丽，主要特点为雄、奇、险、秀、幽、奥等。泰山巍峨，雄奇，沉浑，峻秀的自然景观常令世人慨叹，更有数不清的名胜古迹，摩崖碑碣，使泰山成了世界少有的历史文化与自然相结合的游览胜地。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  泰山日出是泰山最壮观的奇景之一，当黎明时分，游人站在岱顶举目远眺东方，一线晨曦由灰暗变成淡黄，又由淡黄变成橘红。而天空的云朵，红紫交辉，瞬息万变，漫天彩霞与地平线上的茫茫云海融为一体，犹如巨幅油画从天而降。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  泰山的云海玉盘是泰山的又一奇观。夏天，雨后初晴，大量水蒸气蒸发上升，加之夏季从海上吹来的暖温空气被高压气流控制在海拔1500米左右的高度时，如果无风，在岱顶就会看见白云平铺万里，犹如一个巨大的玉盘悬浮在天地之间。
                </p>
              </ContentSection>
              
              <ContentSection title="历史背景" icon="fa-solid fa-history">
                <p className="text-gray-700 leading-relaxed mb-4">
                  泰山自古以来就是中国人崇拜的神山，有"泰山安，四海皆安"的说法。自秦始皇开始到清代，先后有13代帝王引次亲登泰山封禅或祭祀，另外有24代帝王遣官祭祀72次。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  泰山封禅是中国古代帝王在泰山举行的一种祭祀天地神灵的宗教活动，是古代帝王最高的祭天仪式。封禅的目的是帝王向天地报告自己治理天下的功绩，感谢天地的保佑，并祈求天地继续保佑国家长治久安。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  泰山不仅是帝王封禅的圣地，也是中国古代文化的重要发源地之一。泰山周围有许多古代文化遗址和历史名胜，如岱庙、孔子登临处、普照寺等。泰山还是中国古代文人墨客向往的地方，留下了大量赞美泰山的诗词歌赋和碑刻。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  1987年12月，泰山被列入世界文化与自然双重遗产名录，成为中国第一个世界文化与自然双重遗产。
                </p>
              </ContentSection>
              
              <ContentSection title="必游景点" icon="fa-solid fa-map-pin">
                <ul className="space-y-4">
                  {attraction.highlights.map((highlight, index) => (
                    <li key={index} className="flex">
                      <div className="flex-shrink-0 h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-xs font-medium text-emerald-600">{index + 1}</span>
                      </div>
                      <p className="text-gray-700">{highlight}</p>
                    </li>
                  ))}
                </ul>
              </ContentSection>
              
              <ImageGallery images={attraction.images} title="精美图片集" />
            </div>
            
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="bg-emerald-50 p-6 rounded-xl mb-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">旅行小贴士</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-clock text-emerald-600 mr-2"></i>
                        最佳旅游时间
                      </h4>
                      <p className="text-gray-600 text-sm">
                        春季（4-5月）和秋季（9-11月）是游览泰山的最佳时节。春季万物复苏，山花烂漫；秋季天高气爽，景色宜人。夏季可避暑，但需注意防雨；冬季可赏雪景，但山路较滑，需注意安全。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-mountain text-emerald-600 mr-2"></i>
                        登山路线
                      </h4>
                      <p className="text-gray-600 text-sm">
                        泰山主要有四条登山路线：红门登山线（最经典路线）、天外村登山线（可乘车上山）、天烛峰登山线（自然景观优美）、桃花峪登山线（风景秀丽）。可根据个人体力和兴趣选择。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-bed text-emerald-600 mr-2"></i>
                        住宿建议
                      </h4>
                      <p className="text-gray-600 text-sm">
                        泰山山顶有多家酒店和招待所，可提供住宿服务，方便观赏日出。山顶住宿价格较高，建议提前预订。也可选择在泰山脚下住宿，第二天早起登山看日出。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-temperature-half text-emerald-600 mr-2"></i>
                        注意事项
                      </h4>
                      <p className="text-gray-600 text-sm">
                        泰山海拔较高，气温较低，即使夏季也需携带薄外套。登山前应做好准备工作，穿着舒适的运动鞋，携带足够的饮用水和食物。登山过程中注意安全，不要离开指定路线。
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Mount%20Tai%20trail%20map&sign=edf1f033bdf6a2d75a714bb9ab5ecfbf" 
                    alt="泰山游览路线图"
                    className="w-full h-auto"
                  />
                  <div className="p-4 bg-gray-50">
                    <h4 className="font-medium text-gray-800 mb-1">泰山游览路线图</h4>
                    <p className="text-xs text-gray-500">点击查看大图</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}