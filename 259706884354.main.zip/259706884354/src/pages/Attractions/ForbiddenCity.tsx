import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ImageGallery from '@/components/ImageGallery';
import ContentSection from '@/components/ContentSection';
import { getAttractionById } from '@/data/attractions';

export default function ForbiddenCity() {
  const attraction = getAttractionById('forbiddenCity');
  
  if (!attraction) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">景点未找到</h1>
          <p className="text-gray-600 mb-8">抱歉，请求的景点不存在或已移除。</p>
          <Link to="/" className="inline-block bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300">
            返回首页
          </Link>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh] min-h-[400px]">
          <img 
            src={attraction.images[0]} 
            alt={attraction.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex items-end">
            <div className="container mx-auto px-4 pb-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{attraction.name}</h1>
                <div className="flex items-center text-gray-200">
                  <i className="fa-solid fa-map-marker-alt mr-2"></i>
                  <span>{attraction.location}</span>
                  <span className="mx-3">•</span>
                  <span>{attraction.level}</span>
                </div>
              </motion.div></div>
          </div>
          
          <div className="absolute top-4 left-4">
            <Link to="/" className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300 backdrop-blur-sm">
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </div>
        </section>
        
        {/* Content Sections */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <ContentSection title="景点概述" icon="fa-solid fa-info-circle">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">地理位置</h4>
                    <p className="font-medium text-gray-800">{attraction.location}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">景区等级</h4>
                    <p className="font-medium text-gray-800">{attraction.level}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">建议游玩时间</h4>
                    <p className="font-medium text-gray-800">{attraction.suggestedTime}</p>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  北京故宫是中国明清两代的皇家宫殿，旧称紫禁城，位于北京中轴线的中心，是中国古代宫廷建筑之精华。故宫以三大殿为中心，占地面积72万平方米，建筑面积约15万平方米，有大小宫殿七十多座，房屋九千余间。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  故宫是世界上现存规模最大、保存最为完整的木质结构古建筑之一，是国家AAAAA级旅游景区，1987年被列为世界文化遗产。故宫现为故宫博物院，收藏有大量古代艺术珍品，是中国最大的古代文化艺术博物馆。
                </p>
              </ContentSection>
              
              <ContentSection title="景点特色" icon="fa-solid fa-star">
                <p className="text-gray-700 leading-relaxed mb-4">
                  故宫的建筑布局严格按照《周礼·考工记》中"前朝后市，左祖右社"的帝都营建原则建造，整个故宫，在建筑布置上，用形体变化、高低起伏的手法，组合成一个整体。在功能上符合封建社会的等级制度。同时达到左右均衡和形体变化的艺术效果。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  故宫前部宫殿，当时建筑造型要求宏伟壮丽，庭院明朗开阔，象征封建政权至高无上，太和殿坐落在紫禁城对角线的中心，四角上各有十只吉祥瑞兽。后部内廷则要求庭院深邃，建筑紧凑，因此东西六宫都自成一体，各有宫门宫墙，相对排列，秩序井然。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  故宫的建筑中，不同形式的屋顶就有10种以上。以三大殿为例，屋顶各不相同。故宫建筑屋顶满铺各色琉璃瓦件。主要殿座以黄色为主，绿色用于皇子居住区的建筑。其它蓝、紫、黑、翠以及孔雀绿、宝石蓝等五色缤纷的琉璃，多用在花园或琉璃壁上。
                </p>
              </ContentSection>
              
              <ContentSection title="历史背景" icon="fa-solid fa-history">
                <p className="text-gray-700 leading-relaxed mb-4">
                  故宫始建于明成祖永乐四年（1406年），以南京故宫为蓝本营建，到永乐十八年（1420年）建成，成为明清两朝二十四位皇帝的皇宫。民国十四年国庆节（1925年10月10日）故宫博物院正式成立开幕。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  紫禁城建成后，经历了明、清两个王朝，到1911年清帝逊位的约五百年间，历经了明、清两个朝代二十四位皇帝。是明清两朝最高统治核心的代名词。明清宫廷五百多年的历史，包含了帝后活动，等级制度、权力斗争、宗教祭祀等。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  1949年中华人民共和国成立后，故宫博物院进行了大规模的修缮和文物整理工作，逐步恢复了故宫的原貌。如今，故宫已成为中国最重要的文化遗产之一，每年吸引着数百万游客前来参观，感受中国古代皇家文化的魅力。
                </p>
              </ContentSection>
              
              <ContentSection title="必游景点" icon="fa-solid fa-map-pin">
                <ul className="space-y-4">
                  {attraction.highlights.map((highlight, index) => (
                    <li key={index} className="flex">
                      <div className="flex-shrink-0 h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-xs font-medium text-emerald-600">{index + 1}</span>
                      </div>
                      <p className="text-gray-700">{highlight}</p>
                    </li>
                  ))}
                </ul>
              </ContentSection>
              
              <ImageGallery images={attraction.images} title="精美图片集" />
            </div>
            
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="bg-emerald-50 p-6 rounded-xl mb-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">旅行小贴士</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-clock text-emerald-600 mr-2"></i>
                        开放时间
                      </h4>
                      <p className="text-gray-600 text-sm">
                        4月1日-10月31日: 8:30-17:00（16:00停止入园）<br />
                        11月1日-次年3月31日: 8:30-16:30（15:30停止入园）<br />
                        周一闭馆（法定节假日除外）
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-ticket text-emerald-600 mr-2"></i>
                        门票信息
                      </h4>
                      <p className="text-gray-600 text-sm">
                        旺季（4月1日-10月31日）: 60元/人<br />
                        淡季（11月1日-次年3月31日）: 40元/人<br />
                        珍宝馆和钟表馆各需另购门票，各10元/人<br />
                        建议提前在官网预约购票
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-shoe-prints text-emerald-600 mr-2"></i>
                        游览建议
                      </h4>
                      <p className="text-gray-600 text-sm">
                        故宫景区较大，建议安排半天时间游览。入口为午门，出口为神武门或东华门。建议提前下载故宫博物院官方APP，可提供免费讲解服务。景区内无餐饮设施，建议提前准备饮用水和小点心。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-subway text-emerald-600 mr-2"></i>
                        交通指南
                      </h4>
                      <p className="text-gray-600 text-sm">
                        地铁: 1号线"天安门东"站或"天安门西"站下车，步行前往午门<br />
                        公交: 1、2、52、59、82、120等多路公交车可达天安门广场<br />
                        故宫周边禁止社会车辆通行，建议公共交通出行
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Forbidden%20City%20map%20layout&sign=1d3f57601490be2c186ce6a91b9bb192" 
                    alt="故宫导览图"
                    className="w-full h-auto"
                  />
                  <div className="p-4 bg-gray-50">
                    <h4 className="font-medium text-gray-800 mb-1">故宫导览图</h4>
                    <p className="text-xs text-gray-500">点击查看大图</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}