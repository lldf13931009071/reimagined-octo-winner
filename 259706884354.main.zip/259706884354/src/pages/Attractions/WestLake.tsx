import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ImageGallery from '@/components/ImageGallery';
import ContentSection from '@/components/ContentSection';
import { getAttractionById } from '@/data/attractions';

export default function WestLake() {
  const attraction = getAttractionById('westLake');
  
  if (!attraction) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">景点未找到</h1>
          <p className="text-gray-600 mb-8">抱歉，请求的景点不存在或已移除。</p>
          <Link to="/" className="inline-block bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300">
            返回首页
          </Link>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh] min-h-[400px]">
          <img 
            src={attraction.images[0]} 
            alt={attraction.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex items-end">
            <div className="container mx-auto px-4 pb-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{attraction.name}</h1>
                <div className="flex items-center text-gray-200">
                  <i className="fa-solid fa-map-marker-alt mr-2"></i>
                  <span>{attraction.location}</span>
                  <span className="mx-3">•</span>
                  <span>{attraction.level}</span>
                </div>
              </motion.div>
            </div>
          </div>
          
          <div className="absolute top-4 left-4">
            <Link to="/" className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300 backdrop-blur-sm">
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </div>
        </section>
        
        {/* Content Sections */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <ContentSection title="景点概述" icon="fa-solid fa-info-circle">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">地理位置</h4>
                    <p className="font-medium text-gray-800">{attraction.location}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">景区等级</h4>
                    <p className="font-medium text-gray-800">{attraction.level}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">建议游玩时间</h4>
                    <p className="font-medium text-gray-800">{attraction.suggestedTime}</p>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  西湖是中国大陆首批国家重点风景名胜区和中国十大风景名胜之一，是中国大陆主要的观赏性淡水湖泊之一。西湖三面环山，面积约6.39平方千米，东西宽约2.8千米，南北长约3.2千米，绕湖一周近15千米。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  湖中被孤山、白堤、苏堤、杨公堤分隔，按面积大小分别为外西湖、西里湖、北里湖、小南湖及岳湖等五片水面，苏堤、白堤越过湖面，小瀛洲、湖心亭、阮公墩三个小岛鼎立于外西湖湖心，夕照山的雷峰塔与宝石山的保俶塔隔湖相映，由此形成了"一山、二塔、三岛、三堤、五湖"的基本格局。
                </p>
              </ContentSection>
              
              <ContentSection title="景点特色" icon="fa-solid fa-star">
                <p className="text-gray-700 leading-relaxed mb-4">
                  西湖以其秀丽的湖光山色和众多的名胜古迹而闻名中外，以湖为主体，旧称武林水、钱塘湖、西子湖，宋代始称西湖。"上有天堂，下有苏杭"，这句名言充分表达了古往今来人们对杭州西湖的赞美。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  西湖的美在于晴中见潋滟，雨中显空蒙。无论雨雪晴阴，在落霞、烟雾下都能成景；在春花，秋月，夏荷，冬雪中各具美态。湖区以苏堤和白堤的优美风光见称，苏堤和白堤横贯于西湖，把西湖分隔为西里湖，小南湖，岳湖，外湖和里湖五部分。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  西湖不仅自然风光秀丽，还拥有丰富的文化底蕴，历代文人墨客留下了大量赞美西湖的诗词歌赋，为西湖增添了浓厚的文化气息。
                </p>
              </ContentSection>
              
              <ContentSection title="历史背景" icon="fa-solid fa-history">
                <p className="text-gray-700 leading-relaxed mb-4">
                  西湖在唐宋时期已成为著名游览胜地，有"人间天堂"的美誉。西湖的名称最早始于唐朝，在唐朝之前西湖有武林水、明圣湖、金牛湖、龙川、钱源、钱塘湖、上湖等名称。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  自唐代起，西湖就不断得到疏浚和治理。白居易任杭州刺史时，修筑了著名的"白堤"，苏轼任杭州知州时，又修筑了"苏堤"，这些水利工程既解决了杭州的水患问题，又美化了西湖的景观。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  西湖文化景观是自然美与人文美完美结合的典范，2011年6月24日，在法国巴黎举行的第35届世界遗产大会上，"中国杭州西湖文化景观"被列入新的世界遗产名录。西湖是中国传统文化的重要象征，也是中外游客向往的旅游胜地。
                </p>
              </ContentSection>
              
              <ContentSection title="必游景点" icon="fa-solid fa-map-pin">
                <ul className="space-y-4">
                  {attraction.highlights.map((highlight, index) => (
                    <li key={index} className="flex">
                      <div className="flex-shrink-0 h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-xs font-medium text-emerald-600">{index + 1}</span>
                      </div>
                      <p className="text-gray-700">{highlight}</p>
                    </li>
                  ))}
                </ul>
              </ContentSection>
              
              <ImageGallery images={attraction.images} title="精美图片集" />
            </div>
            
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="bg-emerald-50 p-6 rounded-xl mb-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">旅行小贴士</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-clock text-emerald-600 mr-2"></i>
                        最佳旅游时间
                      </h4>
                      <p className="text-gray-600 text-sm">
                        春季（3-5月）和秋季（9-11月）是游览西湖的最佳时节。春季苏堤春晓，桃花盛开；秋季桂花飘香，气候宜人。夏季可赏荷花，冬季可赏断桥残雪。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-shoe-prints text-emerald-600 mr-2"></i>
                        游览建议
                      </h4>
                      <p className="text-gray-600 text-sm">
                        西湖景区较大，建议安排1-2天时间游览。可选择步行、骑行或乘坐游船。租自行车环湖游览是不错的选择，可以自由安排行程，欣赏沿途美景。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-utensils text-emerald-600 mr-2"></i>
                        餐饮推荐
                      </h4>
                      <p className="text-gray-600 text-sm">
                        西湖醋鱼、东坡肉、龙井虾仁是杭州的特色美食，值得一试。西湖周边有许多餐厅和小吃店，可根据个人口味和预算选择。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-camera text-emerald-600 mr-2"></i>
                        摄影提示
                      </h4>
                      <p className="text-gray-600 text-sm">
                        清晨和傍晚是拍摄西湖美景的最佳时段，光线柔和，游客较少。三潭印月、雷峰塔、断桥残雪等景点是经典的摄影取景地。
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=West%20Lake%20Hangzhou%20map%20tourist%20route&sign=2002721b097f04c2ea13df01f073a109" 
                    alt="西湖游览地图"
                    className="w-full h-auto"
                  />
                  <div className="p-4 bg-gray-50">
                    <h4 className="font-medium text-gray-800 mb-1">西湖景区地图</h4>
                    <p className="text-xs text-gray-500">点击查看大图</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}