import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ImageGallery from '@/components/ImageGallery';
import ContentSection from '@/components/ContentSection';
import { getAttractionById } from '@/data/attractions';

export default function Jiuzhaigou() {
  const attraction = getAttractionById('jiuzhaigou');
  
  if (!attraction) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">景点未找到</h1>
          <p className="text-gray-600 mb-8">抱歉，请求的景点不存在或已移除。</p>
          <Link to="/" className="inline-block bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-full transition-colors duration-300">
            返回首页
          </Link>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh] min-h-[400px]">
          <img 
            src={attraction.images[0]} 
            alt={attraction.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent flex items-end">
            <div className="container mx-auto px-4 pb-12">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-2">{attraction.name}</h1>
                <div className="flex items-center text-gray-200">
                  <i className="fa-solid fa-map-marker-alt mr-2"></i>
                  <span>{attraction.location}</span>
                  <span className="mx-3">•</span>
                  <span>{attraction.level}</span>
                </div>
              </motion.div>
            </div>
          </div>
          
          <div className="absolute top-4 left-4">
            <Link to="/" className="bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors duration-300 backdrop-blur-sm">
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </div>
        </section>
        
        {/* Content Sections */}
        <section className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2">
              <ContentSection title="景点概述" icon="fa-solid fa-info-circle">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">地理位置</h4>
                    <p className="font-medium text-gray-800">{attraction.location}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">景区等级</h4>
                    <p className="font-medium text-gray-800">{attraction.level}</p>
                  </div>
                  
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="text-sm text-gray-500 mb-1">建议游玩时间</h4>
                    <p className="font-medium text-gray-800">{attraction.suggestedTime}</p>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  九寨沟以绝天下的原始、神秘而闻名。自然景色兼有湖泊、瀑布、雪山、森林之美，有"童话世界"的美誉。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  九寨沟的精灵是水，湖、泉、瀑、溪、河、滩，连缀一体，飞动与静谧结合，刚烈与温柔相济，千颜万色，多姿多彩。高低错落的群瀑高唱低吟；大大小小的群海碧蓝澄澈，水中倒映红叶、绿树、雪峰、蓝天，一步一色，变幻无穷。
                </p>
              </ContentSection>
              
              <ContentSection title="景点特色" icon="fa-solid fa-star">
                <p className="text-gray-700 leading-relaxed mb-4">
                  九寨沟以高山湖泊群、瀑布、彩林、雪峰、蓝冰和藏族风情并称"九寨沟六绝"，被世人誉为"童话世界"，号称"水景之王"。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  九寨沟的湖水呈现出独特的蓝绿色，这是由于湖水中含有大量的碳酸钙质和藻类，在阳光照射下形成的特殊光学现象。每当天气晴朗，湖水清澈见底，倒映着周围的雪山、森林，构成一幅绝美的画卷。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  九寨沟四季景色各异：春季嫩芽点绿，瀑流轻快；夏季绿荫围湖，莺飞燕舞；秋季红叶铺山，彩林满目；冬季雪裹山峦，冰瀑如玉。
                </p>
              </ContentSection>
              
              <ContentSection title="历史背景" icon="fa-solid fa-history">
                <p className="text-gray-700 leading-relaxed mb-4">
                  九寨沟古称"翠海"，因沟内有树正、荷叶、则查洼等九个藏族村寨而得名。九寨沟的发现和开发相对较晚，直到20世纪70年代，九寨沟才被外界所知。
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  1982年，九寨沟被列为国家重点风景名胜区；1992年，正式被列入《世界自然遗产名录》；1997年，被纳入世界人与生物圈保护区；2007年，被评为国家AAAAA级旅游景区。
                </p>
                <p className="text-gray-700 leading-relaxed">
                  2017年8月8日，九寨沟发生7.0级地震，造成部分景观损坏。经过几年的修复和保护，九寨沟于2020年部分开放，展现出了更强的生命力。如今，九寨沟依然是中国最受欢迎的旅游目的地之一，每年吸引着数百万游客前来观赏其独特的自然美景。
                </p>
              </ContentSection>
              
              <ContentSection title="必游景点" icon="fa-solid fa-map-pin">
                <ul className="space-y-4">
                  {attraction.highlights.map((highlight, index) => (
                    <li key={index} className="flex">
                      <div className="flex-shrink-0 h-6 w-6 rounded-full bg-emerald-100 flex items-center justify-center mr-3 mt-0.5">
                        <span className="text-xs font-medium text-emerald-600">{index + 1}</span>
                      </div>
                      <p className="text-gray-700">{highlight}</p>
                    </li>
                  ))}
                </ul>
              </ContentSection>
              
              <ImageGallery images={attraction.images} title="精美图片集" />
            </div>
            
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <div className="bg-emerald-50 p-6 rounded-xl mb-8">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">旅行小贴士</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-clock text-emerald-600 mr-2"></i>
                        最佳旅游时间
                      </h4>
                      <p className="text-gray-600 text-sm">
                        秋季（9-10月）是九寨沟最美的季节，此时彩林遍布，景色迷人。春季和夏季也各有特色，可以根据个人喜好选择。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-shoe-prints text-emerald-600 mr-2"></i>
                        游览建议
                      </h4>
                      <p className="text-gray-600 text-sm">
                        建议游玩2-3天，可以充分欣赏九寨沟的美景。景区内有观光车，可按需乘坐。由于海拔较高，注意防晒和适当休息。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-utensils text-emerald-600 mr-2"></i>
                        餐饮推荐
                      </h4>
                      <p className="text-gray-600 text-sm">
                        景区内有多个餐厅，提供当地特色美食如牦牛肉、酥油茶等。也可自带干粮和水，但请注意保护环境，不乱扔垃圾。
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2 flex items-center">
                        <i className="fa-solid fa-temperature-half text-emerald-600 mr-2"></i>
                        注意事项
                      </h4>
                      <p className="text-gray-600 text-sm">
                        九寨沟海拔较高，部分游客可能会有高原反应，请根据自身情况调整行程。景区内天气变化较大，建议携带雨具和保暖衣物。
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=Jiuzhaigou%20Valley%20map%20tourist%20route&sign=aad775f3efc0e557fd87f93cfdee2058" 
                    alt="九寨沟游览地图"
                    className="w-full h-auto"
                  />
                  <div className="p-4 bg-gray-50">
                    <h4 className="font-medium text-gray-800 mb-1">九寨沟景区地图</h4>
                    <p className="text-xs text-gray-500">点击查看大图</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}