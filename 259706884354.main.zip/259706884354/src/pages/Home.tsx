import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AttractionCard from '@/components/AttractionCard';
import { attractions } from '@/data/attractions';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[80vh] min-h-[600px] overflow-hidden">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=China%20scenic%20landscape%20mountains%20and%20lakes&sign=c26f745dc583898ac4825f50b44c0a05" 
              alt="中国美景"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30"></div>
          </div>
          
          <div className="relative z-10 container mx-auto px-4 h-full flex flex-col justify-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-2xl text-white"
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
                探索中国的<br />自然与文化瑰宝
              </h1>
              <p className="text-lg md:text-xl mb-8 text-gray-100">
                发现中国最令人惊叹的景点，体验千年文明与壮丽自然的完美融合
              </p>
              <div>
                <button className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-6 rounded-full transition-colors duration-300 shadow-lg hover:shadow-xl flex items-center">
                  <span>开始探索</span>
                  <i className="fa-solid fa-arrow-right ml-2"></i>
                </button>
              </div>
            </motion.div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-gray-50 to-transparent"></div>
        </section>
        
        {/* Featured Attractions Section */}
        <section className="container mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-3">精选景点</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              探索中国最具代表性的自然景观和文化遗产，每一处景点都有其独特的魅力和故事
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
            {attractions.map((attraction) => (
              <AttractionCard key={attraction.id} attraction={attraction} />
            ))}
          </div>
        </section>
        
        {/* Features Section */}
        <section className="bg-gradient-to-br from-emerald-50 to-blue-50 py-16">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-800 mb-3">为什么选择我们</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                我们提供全面、专业的旅游信息，让您的旅行更加丰富多彩
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                  <i className="fa-solid fa-info-circle text-2xl text-emerald-600"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">详细的景点介绍</h3>
                <p className="text-gray-600">
                  每个景点都配有详细的介绍，包括地理位置、景区特色、历史背景等信息，让您提前了解目的地。
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                  <i className="fa-solid fa-camera text-2xl text-emerald-600"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">精美的图片集</h3>
                <p className="text-gray-600">
                  每个景点提供多张高质量图片，展示不同角度和季节的美景，让您身临其境般感受景点魅力。
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300">
                <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                  <i className="fa-solid fa-map-signs text-2xl text-emerald-600"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">实用的旅行建议</h3>
                <p className="text-gray-600">
                  提供建议游玩时间、必游景点等实用信息，帮助您规划完美的旅行行程，不错过任何精彩。
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action Section */}
        <section className="py-16 bg-emerald-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">准备好开始您的中国之旅了吗？</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto text-emerald-100">
              探索中国的自然奇观和文化遗产，创造难忘的旅行记忆
            </p>
            <button className="bg-white text-emerald-600 hover:bg-gray-100 font-bold py-3 px-8 rounded-full transition-colors duration-300 shadow-lg hover:shadow-xl text-lg">
              了解更多景点
            </button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}