import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-6">关于我们</h1>
            
            <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3">
                  <div className="rounded-lg overflow-hidden h-64">
                    <img 
                      src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=travel%20team%20exploring%20mountain%20landscape&sign=413ec33d0a31302f665bce03c4689366" 
                      alt="我们的团队"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                
                <div className="md:w-2/3">
                  <h2 className="text-2xl font-bold text-gray-800 mb-4">探索中国旅行网</h2>
                  <p className="text-gray-600 mb-4">
                    探索中国旅行网成立于2023年，是一家专注于推广中国优秀旅游资源的在线平台。我们致力于为旅行者提供全面、准确、实用的旅游信息，帮助人们更好地了解和欣赏中国的自然景观和文化遗产。
                  </p>
                  <p className="text-gray-600">
                    我们的团队由一群热爱旅行、熟悉中国各地风土人情的专业人士组成，希望通过我们的努力，让更多人发现中国之美，体验中华文化的博大精深。
                  </p>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm p-6 text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fa-solid fa-map-marked-alt text-2xl text-emerald-600"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">精选景点</h3>
                <p className="text-gray-600">我们精心挑选中国最具代表性的景点，提供详细的介绍和实用的旅行建议。</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm p-6 text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fa-solid fa-camera text-2xl text-emerald-600"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">精美图片</h3>
                <p className="text-gray-600">每个景点都配有高质量图片，让您在出发前就能领略景点的美丽风光。</p>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm p-6 text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fa-solid fa-history text-2xl text-emerald-600"></i>
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">文化底蕴</h3>
                <p className="text-gray-600">深入介绍每个景点的历史背景和文化价值，让旅行不仅是观光，更是文化体验。</p>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4">联系我们</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start">
                  <div className="mt-1 mr-4 text-emerald-600">
                    <i className="fa-solid fa-envelope"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">电子邮箱</h4>
                    <p className="text-gray-600">contact@travelchina.com</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="mt-1 mr-4 text-emerald-600">
                    <i className="fa-solid fa-phone"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">电话</h4>
                    <p className="text-gray-600">+86 123 4567 8910</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="mt-1 mr-4 text-emerald-600">
                    <i className="fa-solid fa-map-marker-alt"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">地址</h4>
                    <p className="text-gray-600">北京市朝阳区建国路88号旅游大厦15层</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="mt-1 mr-4 text-emerald-600">
                    <i className="fa-solid fa-clock"></i>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">工作时间</h4>
                    <p className="text-gray-600">周一至周五: 9:00 - 18:00</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}