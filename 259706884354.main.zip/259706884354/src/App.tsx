import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import About from "@/pages/About";
import Jiuzhaigou from "@/pages/Attractions/Jiuzhaigou";
import WestLake from "@/pages/Attractions/WestLake";
import ForbiddenCity from "@/pages/Attractions/ForbiddenCity";
import GreatWall from "@/pages/Attractions/GreatWall";
import MountTai from "@/pages/Attractions/MountTai";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/attractions/jiuzhaigou" element={<Jiuzhaigou />} />
        <Route path="/attractions/westLake" element={<WestLake />} />
        <Route path="/attractions/forbiddenCity" element={<ForbiddenCity />} />
        <Route path="/attractions/greatWall" element={<GreatWall />} />
        <Route path="/attractions/mountTai" element={<MountTai />} />
        <Route path="*" element={<div className="text-center text-xl py-10">页面未找到</div>} />
      </Routes>
    </AuthContext.Provider>
  );
}
