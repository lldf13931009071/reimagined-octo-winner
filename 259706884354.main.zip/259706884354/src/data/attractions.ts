import { Attraction } from '@/types/attraction';

export const attractions: Attraction[] = [
  {
    id: 'jiuzhaigou',
    name: '九寨沟',
    description: '九寨沟以绝天下的原始、神秘而闻名。自然景色兼有湖泊、瀑布、雪山、森林之美，有"童话世界"的美誉。',
    location: '四川省阿坝藏族羌族自治州九寨沟县',
    level: '国家AAAAA级旅游景区',
    suggestedTime: '1-3天',
    features: '九寨沟以高山湖泊群、瀑布、彩林、雪峰、蓝冰和藏族风情并称"九寨沟六绝"，被世人誉为"童话世界"，号称"水景之王"。',
    history: '九寨沟古称"翠海"，因沟内有树正、荷叶、则查洼等九个藏族村寨而得名。1982年被列为国家重点风景名胜区，1992年被列入《世界自然遗产名录》，2007年被评为国家AAAAA级旅游景区。九寨沟在2017年遭遇地震后进行了修复，于2020年部分开放，展现出了更强的生命力。',
    highlights: [
      '五彩池 - 九寨沟最小但颜色最丰富的海子',
      '长海 - 九寨沟最大的海子，冬季会部分结冰',
      '诺日朗瀑布 - 中国最宽的高山瀑布',
      '树正群海 - 由19个大小不同的海子组成',
      '珍珠滩 - 电视剧《西游记》取景地'
    ],
    images: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Jiuzhaigou%20Valley%20colorful%20lake%20blue%20water%20natural%20landscape&sign=f794727d1108fa50e7dc99ae422d2ce4',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Jiuzhaigou%20Valley%20waterfall%20scenic%20view&sign=1863ee5b8d92c970b0cbc04fb12dafd8',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Jiuzhaigou%20autumn%20scenery%20colorful%20forest&sign=60b4e25151dd428126b654ac5e38950b',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Jiuzhaigou%20Five%20Color%20Lake%20crystal%20clear%20water&sign=fea08611c01977363e836f132c3aa6b8',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Jiuzhaigou%20winter%20snow%20scenery&sign=cd8637df8658990e74eef9bf9543cc2a'
    ]
  },
  {
    id: 'westLake',
    name: '西湖',
    description: '西湖是中国大陆首批国家重点风景名胜区和中国十大风景名胜之一，是中国大陆主要的观赏性淡水湖泊之一。',
    location: '浙江省杭州市西湖区',
    level: '国家AAAAA级旅游景区',
    suggestedTime: '1-2天',
    features: '西湖以其秀丽的湖光山色和众多的名胜古迹而闻名中外，以湖为主体，旧称武林水、钱塘湖、西子湖，宋代始称西湖。',
    history: '西湖在唐宋时期已成为著名游览胜地，有"人间天堂"的美誉。西湖文化景观是自然美与人文美完美结合的典范，2011年被列入《世界遗产名录》。西湖周围有大量的历史遗迹和文化景观，体现了中国传统山水文化的精髓。',
    highlights: [
      '三潭印月 - 西湖十景之一，一元人民币纸币背面图案',
      '断桥残雪 - 西湖最著名的桥，传说中白娘子与许仙相遇的地方',
      '雷峰塔 - 因《白蛇传》而闻名的古塔',
      '苏堤春晓 - 苏东坡主持修建的长堤，春季桃花盛开',
      '曲院风荷 - 以夏日荷花景观为特色'
    ],
    images: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=West%20Lake%20Hangzhou%20scenic%20view&sign=a8a099b182885eb375b987edc976c17f',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=West%20Lake%20Three%20Pools%20Mirroring%20the%20Moon&sign=139df87827907176e46652671a859ff5',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=West%20Lake%20Broken%20Bridge%20spring%20scenery&sign=d5fa908f1c5ff350fd9546ca2efc84b2',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Leifeng%20Pagoda%20West%20Lake%20sunset&sign=192f0187d8105cea128f56b3136b6a06',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=West%20Lake%20lotus%20flowers%20summer&sign=e7ae066b676eb69a1993fee584d07879'
    ]
  },
  {
    id: 'forbiddenCity',
    name: '故宫',
    description: '北京故宫是中国明清两代的皇家宫殿，旧称紫禁城，位于北京中轴线的中心，是中国古代宫廷建筑之精华。',
    location: '北京市东城区景山前街4号',
    level: '国家AAAAA级旅游景区，世界文化遗产',
    suggestedTime: '3-4小时',
    features: '故宫以三大殿为中心，占地面积72万平方米，建筑面积约15万平方米，有大小宫殿七十多座，房屋九千余间，是世界上现存规模最大、保存最为完整的木质结构古建筑之一。',
    history: '故宫始建于明成祖永乐四年（1406年），以南京故宫为蓝本营建，到永乐十八年（1420年）建成，成为明清两朝二十四位皇帝的皇宫。1987年被列为世界文化遗产，是中国传统文化的重要象征。',
    highlights: [
      '太和殿 - 故宫最大的宫殿，举行重大典礼的地方',
      '中和殿 - 皇帝参加大典前休息的地方',
      '保和殿 - 科举考试殿试的举办地',
      '乾清宫 - 明清皇帝的寝宫',
      '御花园 - 皇帝的私家花园'
    ],
    images: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Forbidden%20City%20Beijing%20main%20gate&sign=ebe2c1d97ab70f013c1c9673737f7a6e',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Hall%20of%20Supreme%20Harmony%20Forbidden%20City&sign=16eb8290a04134803a46dc02386e7743',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Forbidden%20City%20inner%20courtyard&sign=70c5213d81774d95914536be202562cf',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Forbidden%20City%20imperial%20garden&sign=d6beed4a03d55594880a4289287d68a1',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Forbidden%20City%20sunset%20view&sign=a37624ac6c4ae2ba1aa677b0a9fcc6e6'
    ]
  },
  {
    id: 'greatWall',
    name: '长城',
    description: '长城是中国古代的军事防御工程，是世界文化遗产之一，也是世界七大奇迹之一。',
    location: '主要分布在河北、北京、天津、山西、陕西、甘肃等省市',
    level: '国家AAAAA级旅游景区，世界文化遗产',
    suggestedTime: '根据游览段落不同，1-3小时不等',
    features: '长城修筑的历史可上溯到西周时期，秦灭六国统一天下后，秦始皇连接和修缮战国长城，始有"万里长城"之称。长城不是一道单纯孤立的城墙，而是以城墙为主体，同大量的城、障、亭、标相结合的防御体系。',
    history: '长城始建于西周时期，著名的典故"烽火戏诸侯"就源于此。春秋战国时期列国争霸，互相防守，长城修筑进入第一个高潮，但此时修筑的长度都比较短。秦统一六国后，秦始皇派蒙恬北伐匈奴，并连接各国长城，始成万里长城。明朝是最后一个大修长城的朝代，今天人们所看到的长城多是此时修筑。',
    highlights: [
      '八达岭长城 - 最著名的长城段落，交通便利',
      '慕田峪长城 - 景色秀美，植被覆盖率高',
      '司马台长城 - 保留了原始风貌，险峻壮观',
      '嘉峪关 - 明长城最西端的关口',
      '山海关 - 明长城的东起点，有"天下第一关"之称'
    ],
    images: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Great%20Wall%20of%20China%20Badaling%20section&sign=460c5047c209c6ec8c3fa6bd484b4968',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Great%20Wall%20sunset%20mountain%20view&sign=0662767c891d91c2468d341c2a855a98',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Great%20Wall%20Mutianyu%20section%20autumn&sign=2eb7612c829245fdb72bef89db498f3c',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Great%20Wall%20snow%20winter%20scenery&sign=a065d4d8bd2889249ed7ff516c80accf',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Great%20Wall%20watchtower%20closeup&sign=11c16bf85f73d0852b106299eea84783'
    ]
  },
  {
    id: 'mountTai',
    name: '泰山',
    description: '泰山是中国五岳之首，有"天下第一山"之称，是中国传统文化中"天人合一"思想的寄托之地。',
    location: '山东省泰安市泰山区',
    level: '国家AAAAA级旅游景区，世界文化与自然双重遗产',
    suggestedTime: '1-2天',
    features: '泰山拥有丰富的自然景观和人文景观，被誉为"五岳独尊"。泰山以其雄伟壮观的景色和深厚的文化底蕴吸引着无数游客和文人墨客。',
    history: '泰山自古以来就是中国人崇拜的神山，有"泰山安，四海皆安"的说法。自秦始皇开始到清代，先后有13代帝王引次亲登泰山封禅或祭祀，另外有24代帝王遣官祭祀72次。泰山于1987年被列入世界文化与自然双重遗产名录。',
    highlights: [
      '玉皇顶 - 泰山主峰，海拔1545米',
      '十八盘 - 泰山最陡峭的登山路段',
      '南天门 - 登山盘道顶端，进入天庭的门户',
      '碧霞祠 - 供奉碧霞元君的道教圣地',
      '日观峰 - 观赏泰山日出的最佳地点'
    ],
    images: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mount%20Tai%20sunrise%20sea%20of%20clouds&sign=7ab32ecf46d4a8a0cc752830adab78d4',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mount%20Tai%2018%20bends%20steep%20path&sign=0cd192828853de8e3a922b509e8caf21',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mount%20Tai%20South%20Gate%20to%20Heaven&sign=e9b0703d4ba7ca8bdaa43c13db164cf8',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mount%20Tai%20Jade%20Emperor%20Summit&sign=0bffca2f1da238ad152ade6e6b6e1421',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Mount%20Tai%20ancient%20stone%20carvings&sign=8503b4884d40b2674cf6d3704f1f1cf9'
    ]
  }
];

export const getAttractionById = (id: string): Attraction | undefined => {
  return attractions.find(attraction => attraction.id === id);
};