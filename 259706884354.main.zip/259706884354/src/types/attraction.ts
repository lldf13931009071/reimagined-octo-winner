export interface Attraction {
  id: string;
  name: string;
  description: string;
  location: string;
  level: string;
  suggestedTime: string;
  features: string;
  history: string;
  highlights: string[];
  images: string[];
}